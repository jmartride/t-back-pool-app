T-BACK Pool Team web/PWA package
Upload the contents of this ZIP (not the ZIP itself) to your GitHub Pages repository root. Enable GitHub Pages in repository Settings > Pages. Open the published HTTPS address on Android Chrome and choose Install app or Add to Home screen.

IMPORTANT: Opening index.html directly in Chrome supports the web app, but install/offline service worker requires HTTPS hosting (or localhost). Data is stored separately in each browser/device; use Export backup frequently. Publishing a new app version must preserve the browser's storage and origin.
